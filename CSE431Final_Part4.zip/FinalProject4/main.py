import time
import random

sortedList = []

#BST Implementation from https://www.programiz.com/dsa/binary-search-tree
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None



def inorder(root):
    if root is not None:

        inorder(root.left)


        print(str(root.key) + "->", end=' ')


        inorder(root.right)



def insert(node, key):


    if node is None:
        return Node(key)


    if key < node.key:
        node.left = insert(node.left, key)
    else:
        node.right = insert(node.right, key)

    return node



def minValueNode(node):
    current = node


    while(current.left is not None):
        current = current.left

    return current



def deleteNode(root, key):


    if root is None:
        return root


    if key < root.key:
        root.left = deleteNode(root.left, key)
    elif(key > root.key):
        root.right = deleteNode(root.right, key)
    else:

        if root.left is None:
            temp = root.right
            root = None
            return temp

        elif root.right is None:
            temp = root.left
            root = None
            return temp


        temp = minValueNode(root.right)

        root.key = temp.key


        root.right = deleteNode(root.right, temp.key)

    return root

#Binary search implementation from https://www.programiz.com/dsa/binary-search
def binarySearch(array, x, low, high):

    if high >= low:

        mid = low + (high - low)//2

        # If found at mid, then return it
        if array[mid] == x:
                return mid

        # Search the left half
        elif array[mid] > x:
            return binarySearch(array, x, low, mid-1)

        # Search the right half
        else:
            return binarySearch(array, x, mid + 1, high)

    else:
        return low + (high - low)//2



n = 100
testsPerN = 50000
bstInsertionTimes = []
vectorInsertionTimes = []

for i in range(1, n):
    lastTime = time.time()
    root = None
    for j in range(testsPerN):
        root = insert(root, random.randrange(1, 1000))

    bstInsertionTimes.append(time.time() - lastTime)
    testsPerN += 1000


testsPerN = 50000
for i in range(1, n):
    lastTime = time.time()
    root = None
    for j in range(testsPerN):
        value = random.randrange(0, 1000)
        index = binarySearch(sortedList, value, 0, len(sortedList) - 1)

        sortedList.insert(index, value)

    vectorInsertionTimes.append(time.time() - lastTime)
    testsPerN += 1000
    sortedList.clear()

print(bstInsertionTimes)
print(vectorInsertionTimes)