import random
import time


#hash table implementation from https://www.programiz.com/dsa/hash-table
hashTable = [[],] * 1000

def checkPrime(n):
    if n == 1 or n == 0:
        return 0

    for i in range(2, n//2):
        if n % i == 0:
            return 0

    return 1


def getPrime(n):
    if n % 2 == 0:
        n = n + 1

    while not checkPrime(n):
        n += 2

    return n


def hashFunction(key):
    capacity = getPrime(10)
    return key % capacity


def insertData(key, data):
    index = hashFunction(key)
    hashTable[index] = [key, data]

def removeData(key):
    index = hashFunction(key)
    hashTable[index] = 0


#BST Implementation from https://www.programiz.com/dsa/binary-search-tree
class Node:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None



def inorder(root):
    if root is not None:

        inorder(root.left)


        print(str(root.key) + "->", end=' ')


        inorder(root.right)



def insert(node, key):


    if node is None:
        return Node(key)


    if key < node.key:
        node.left = insert(node.left, key)
    else:
        node.right = insert(node.right, key)

    return node



def minValueNode(node):
    current = node


    while(current.left is not None):
        current = current.left

    return current



def deleteNode(root, key):


    if root is None:
        return root


    if key < root.key:
        root.left = deleteNode(root.left, key)
    elif(key > root.key):
        root.right = deleteNode(root.right, key)
    else:

        if root.left is None:
            temp = root.right
            root = None
            return temp

        elif root.right is None:
            temp = root.left
            root = None
            return temp


        temp = minValueNode(root.right)

        root.key = temp.key


        root.right = deleteNode(root.right, temp.key)

    return root


n = 100
testsPerN = 50000
bstInsertionTimes = []
hashTableInsertionTimes = []

for i in range(1, n):
    lastTime = time.time()
    root = None
    for j in range(testsPerN):
        root = insert(root, random.randrange(1, 1000))

    bstInsertionTimes.append(time.time() - lastTime)
    testsPerN += 1000

for i in range(1, n):
    lastTime = time.time()
    root = None
    for j in range(testsPerN):
        insertData(random.randint(1, 1000), "test")

    hashTableInsertionTimes.append(time.time() - lastTime)


print(bstInsertionTimes)
print(hashTableInsertionTimes)
