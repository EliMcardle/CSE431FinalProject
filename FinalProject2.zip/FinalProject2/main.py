import random
import time
from typing import List

unsortedLists = []

listSizeMax = 100
numListsPerSize = 1000
kValue = 20

def CreateRandomList(listSize):
    outputList = []
    for i in range(1, listSize):
        outputList.append(random.randrange(0, 1000))

    return outputList

tempList = []

for i in range(listSizeMax):
    for j in range(numListsPerSize):
        tempList.append(CreateRandomList(i))

    unsortedLists.append(tempList.copy())
    tempList.clear()

timeofListGeneration = time.time()

hyrbidSortingTimes = []

#Hybrid sort and accompanied functions from https://www.geeksforgeeks.org/advanced-quick-sort-hybrid-algorithm/#
def insertion_sort(arr, low, n):
    for i in range(low + 1, n + 1):
        val = arr[i]
        j = i
        while j>low and arr[j-1]>val:
            arr[j]= arr[j-1]
            j-= 1
        arr[j]= val


def partition(arr, low, high):
    pivot = arr[high]
    i = j = low
    for i in range(low, high):
        if arr[i] < pivot:
            arr[i], arr[j] = arr[j], arr[i]
            j += 1
    arr[j], arr[high] = arr[high], arr[j]
    return j


def quick_sort(arr, low, high):
    if low < high:
        pivot = partition(arr, low, high)
        quick_sort(arr, low, pivot - 1)
        quick_sort(arr, pivot + 1, high)
        return arr


def hybrid_quick_sort(arr, low, high):
    while low < high:
        if high - low + 1 < kValue:
            insertion_sort(arr, low, high)
            break

        else:
            pivot = partition(arr, low, high)


            if pivot - low < high - pivot:
                hybrid_quick_sort(arr, low, pivot - 1)
                low = pivot + 1
            else:

                hybrid_quick_sort(arr, pivot + 1, high)
                high = pivot - 1


tempList = []
for i in range(1, 100):
    kValue = i
    for testCase in unsortedLists:
        lastTime = time.time()
        for unsortedList in testCase:
            copyList = unsortedList.copy()
            hybrid_quick_sort(copyList, 0, len(unsortedList) - 1)
        tempList.append(time.time() - lastTime)
    hyrbidSortingTimes.append(tempList.copy())
    tempList.clear()

topThreeValues = [-1, -1, -1]
bestAverages = [1000, 1000, 1000]

for i in range(len(hyrbidSortingTimes)):
    totalNum = 0
    for value in hyrbidSortingTimes[i]:
        totalNum += value

    if totalNum/ len(hyrbidSortingTimes[i]) < bestAverages[0]:
        bestAverages[2] = bestAverages[1]
        bestAverages[1] = bestAverages[0]
        bestAverages[0] = totalNum/ len(hyrbidSortingTimes[i])
        topThreeValues[2] = topThreeValues[1]
        topThreeValues[1] = topThreeValues[0]
        topThreeValues[0] = i
    elif totalNum/ len(hyrbidSortingTimes[i]) < bestAverages[1]:
        bestAverages[2] = bestAverages[1]
        bestAverages[1] = totalNum/ len(hyrbidSortingTimes[i])
    elif totalNum/ len(hyrbidSortingTimes[i]) < bestAverages[2]:
        bestAverages[2] = totalNum/ len(hyrbidSortingTimes[i])

    total = 0

print(topThreeValues[0])
print(hyrbidSortingTimes[topThreeValues[0]])
print(topThreeValues[1])
print(hyrbidSortingTimes[topThreeValues[1]])
print(topThreeValues[2])
print(hyrbidSortingTimes[topThreeValues[2]])
