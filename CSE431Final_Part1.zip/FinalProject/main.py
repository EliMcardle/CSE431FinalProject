import random
import time
from typing import List

unsortedLists = []

listSizeMax = 100
numListsPerSize = 1000

def CreateRandomList(listSize):
    outputList = []
    for i in range(listSize):
        outputList.append(random.randrange(0, 1000))

    return outputList

tempList = []

for i in range(listSizeMax):
    for j in range(numListsPerSize):
        tempList.append(CreateRandomList(i))

    unsortedLists.append(tempList.copy())
    tempList.clear()

timeofListGeneration = time.time()

insertionSortingTimes = []
quickSortingTimes = []

#Insertion sort implementation from https://www.geeksforgeeks.org/insertion-sort/
def InsertionSort(arr: List[int], n: int) -> None:
    if n <= 1:
        return

    InsertionSort(arr, n - 1)

    last = arr[n - 1]
    j = n - 2

    while j >= 0 and arr[j] > last:
        arr[j + 1] = arr[j]
        j -= 1

    arr[j + 1] = last


#Quick sort implementation from https://www.geeksforgeeks.org/quick-sort/
def partition(array, low, high):
    pivot = array[high]

    i = low - 1

    for j in range(low, high):
        if array[j] <= pivot:
            i = i + 1

            (array[i], array[j]) = (array[j], array[i])

    (array[i + 1], array[high]) = (array[high], array[i + 1])

    return i + 1


def QuickSort(array, low, high):
    if low < high:
        pi = partition(array, low, high)

        QuickSort(array, low, pi - 1)

        QuickSort(array, pi + 1, high)


for testCase in unsortedLists:
    lastTime = time.time()
    for unsortedList in testCase:
        copyList = unsortedList.copy()
        InsertionSort(copyList, len(unsortedList))
    insertionSortingTimes.append(time.time() - lastTime)

for testCase in unsortedLists:
    lastTime = time.time()
    for unsortedList in testCase:
        copyList = unsortedList.copy()
        QuickSort(copyList, 0, len(unsortedList) - 1)
    quickSortingTimes.append(time.time() - lastTime)

print(insertionSortingTimes)
print(quickSortingTimes)